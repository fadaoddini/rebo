<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('back.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




    <div class="top-products-area py-3">
        <div class="container">
            <div class="section-heading d-flex align-items-center justify-content-between">
                <h6 class="ml-1">
                    <a href="<?php echo e(route('index')); ?>">
                        صفحه نخست /
                    </a>
                    <?php echo e($cat->name); ?></h6>
                <!-- Layout Options-->
                <div class="layout-options"><a class="active" href="<?php echo e(route('grid',$cat->slug)); ?>"><i class="lni lni-grid-alt"></i></a><a href="<?php echo e(route('list',$cat->slug)); ?>"><i class="lni lni-radio-button"></i></a></div>
            </div>
            <div class="row g-3">



                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="card top-product-card">
                        <div class="card-body"><span class="badge badge-danger">%<?php echo e($item->takhfif); ?></span>
                            <a class="wishlist-btn" href="#"><i class="lni lni-heart"></i></a>
                            <a class="product-thumbnail d-block" href="<?php echo e(route('single',$item->slug)); ?>">
                                <img class="mb-2" src="<?php echo e(url('images/product/thumb/'.$item->image)); ?>" alt="<?php echo e($item->slug); ?>">

                            </a>
                            <a class="product-title d-block" href="<?php echo e(route('single',$item->slug)); ?>"><?php echo e($item->name); ?></a>
                            <p class="sale-price">

                                <?php echo e((($item->price)-((($item->price)*($item->takhfif))/100))); ?>

                                تومان




                                <span class="real-price"> <?php echo e($item->price); ?> تومان</span></p>
                            <div class="product-rating">

                                <?php for($i=0;$i<($item->ratee);$i++): ?>
                                    <i class="lni lni-star-filled"></i>

                                <?php endfor; ?>

                            </div>
                            <form>

                                <?php echo csrf_field(); ?>
                                <input id="name<?php echo e($item->id); ?>" value="<?php echo e($item->name); ?>" type="hidden">


                                <a onclick="addtoo(<?php echo e($item->id); ?>)" class="btn btn-success btn-sm add2cart-notify" >
                                <i class="lni lni-plus"></i>
                            </a>
                            </form>
                        </div>
                    </div>
                </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\rebo\resources\views/front/grid/main.blade.php ENDPATH**/ ?>