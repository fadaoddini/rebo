
<?php $__env->startSection('webtitleadmin'); ?>
پنل مدیریت سایت
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section>
        داشبورد
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\rebo\resources\views/back/main/index.blade.php ENDPATH**/ ?>