<?php echo e($slot); ?>

<?php /**PATH D:\xamp\htdocs\rebo\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>