<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('index.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
<!-- Preloader-->
<div class="preloader" id="preloader">
    <div class="spinner-grow text-secondary" role="status">
        <div class="sr-only">بارگذاری...</div>
    </div>
</div>
<!-- Header Area-->
<div class="header-area" id="headerArea">
    <div class="container h-100 d-flex align-items-center justify-content-between">

        <?php echo $__env->make('topmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    </div>
</div>
<!-- Sidenav Black Overlay-->
<div class="sidenav-black-overlay"></div>
<!-- Side Nav Wrapper-->



<?php echo $__env->make('sidebare', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<!-- PWA Install Alert-->
<?php echo $__env->make('alertpwa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<div class="page-content-wrapper">
    <!-- Hero Slides-->


    <?php echo $__env->make('topslider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Product Catagories-->


    <?php echo $__env->make('category', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <!-- Flash Sale Slide-->
    <div class="flash-sale-wrapper">
        <div class="container">
            <div class="section-heading d-flex align-items-center justify-content-between">
                <h6 class="ml-1">ویژه</h6><a class="btn btn-primary btn-sm" href="">مشاهده همه</a>
            </div>
            <!-- Flash Sale Slide-->

            <?php echo $__env->make('vije', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>
    <!-- Top Products-->
    <div class="top-products-area clearfix py-3">
        <div class="container">
            <div class="section-heading d-flex align-items-center justify-content-between">
                <h6 class="ml-1">پرفروش ها</h6><a class="btn btn-danger btn-sm" href="">مشاهده همه</a>
            </div>

            <?php echo $__env->make('mostsale', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>
    <!-- Cool Facts Area-->
    <div class="cta-area">
        <div class="container">

            <?php echo $__env->make('ads1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>
    <!-- Weekly Best Sellers-->
    <div class="weekly-best-seller-area py-3">
        <div class="container">
            <div class="section-heading d-flex align-items-center justify-content-between">
                <h6 class="pl-1">بهترین ها</h6><a class="btn btn-success btn-sm" href="">مشاهده همه</a>
            </div>

            <?php echo $__env->make('thebest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



        </div>
    </div>
    <!-- Discount Coupon Card-->
    <div class="container">
        <div class="card discount-coupon-card border-0">
            <div class="card-body">

                <?php echo $__env->make('ads2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


            </div>
        </div>
    </div>
    <!-- Featured Products Wrapper-->
    <div class="featured-products-wrapper py-3">
        <div class="container">
            <div class="section-heading d-flex align-items-center justify-content-between">
                <h6 class="pl-1">محصولات برجسته</h6><a class="btn btn-warning btn-sm" href="">مشاهده همه</a>
            </div>

            <?php echo $__env->make('barjeste', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>
    <!-- Night Mode View Card-->
    <?php echo $__env->make('nightmode', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>
<!-- Internet Connection Status-->
<div class="internet-connection-status" id="internetStatus"></div>
<!-- Footer Nav-->

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</body>
</html>
<?php /**PATH D:\xamp\htdocs\rebo\resources\views/front/index/index.blade.php ENDPATH**/ ?>