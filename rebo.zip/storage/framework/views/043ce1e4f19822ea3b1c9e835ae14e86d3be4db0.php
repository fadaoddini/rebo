<?php $__env->startSection('webtitleadmin'); ?>
    پنل مدیریت کاربران
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="card card-custom card-stretch gutter-b card-shadowless bg-light">
        <!--begin::Header-->
        <div class="card-header border-0 py-5">
            <h3 class="card-title align-items-start flex-column">
                <span class="card-label font-weight-bolder text-dark">ویرایش کاربران</span>

            </h3>

        </div>
        <!--end::Header-->

        <!--begin::Body-->
        <div class="card-body py-0">


            <form method="post" action="<?php echo e(route('adminupadteprofile',$user->id)); ?>">
                <?php echo csrf_field(); ?>
                <div class="row clearfix">

                    <div class="col-lg-3 col-md-6 col-sm-12 form-group">
                        <input class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control" type="text" name="name" value="<?php echo e($user->name); ?>" placeholder="نام" >

                        </span>
                    </div>

                    <div class="col-lg-3 col-md-6 col-sm-12 form-group">
                        <input class="<?php $__errorArgs = ['family'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control" type="text" name="family" value="<?php echo e($user->family); ?>" placeholder="نام خانوادگی" >


                    </div>

                    <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                        <p class="btn btn-light">
                            <?php echo e($user->email); ?>

                        </p>
                    </div>

                    <div class="col-lg-4 col-md-6 col-sm-12 form-group">
                        <input class="<?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control" type="text" name="mobile" value="<?php echo e($user->mobile); ?>" placeholder="09123456789" >


                    </div>


                    <div class="col-lg-4 col-md-6 col-sm-12 form-group">
                        <input class="<?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control" type="text" name="city" value="<?php echo e($user->city); ?>" placeholder="تهران" >


                    </div>






                    <div class="col-lg-4 col-md-12 col-sm-12 form-group">
                        <select class="custom-select-box form-control">
                            <option>نوع اشتراک</option>
                            <option>عضویت عادی</option>
                            <option>عضویت ویژه</option>

                        </select>
                    </div>

                    <div class="form-group col-lg-6 col-md-12 col-sm-12">
                        <label>کلمه عبور</label>
                        <span class="eye-icon flaticon-eye"></span>
                        <input class="<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control" type="password" name="password"  placeholder="کلمه عبور" >

                    </div>




                    <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                        <textarea name="description" class="form-control" placeholder="پیام شما"><?php echo e($user->description); ?></textarea>
                    </div>

                    <div class="col-lg-12 col-md-12 col-sm-12 form-group text-right">
                        <button class="btn font-weight-bolder btn-sm btn-light-danger px-5" type="submit" name="submit-form"><span class="txt">لغو <i class="fa fa-angle-left"></i></span></button>
                        <button class="btn font-weight-bolder btn-sm btn-light-success px-5" type="submit" name="submit-form"><span class="txt">ذخیره تغییرات <i class="fa fa-angle-left"></i></span></button>
                    </div>

                </div>
            </form>


        </div>
        <!--end::Body-->
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\rebo\resources\views/back/user/edit-profile.blade.php ENDPATH**/ ?>