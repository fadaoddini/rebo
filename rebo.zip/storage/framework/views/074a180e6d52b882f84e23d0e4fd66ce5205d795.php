<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('back.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <div class="top-products-area py-3">
        <div class="container">
            <div class="section-heading d-flex align-items-center justify-content-between">

                <h6 class="ml-1">
                    <a href="<?php echo e(route('index')); ?>">
                        صفحه نخست /
                    </a>
                    <?php echo e($cat->name); ?></h6>
                <!-- Layout Options-->
                <div class="layout-options"><a class="active" href="<?php echo e(route('grid',$cat->slug)); ?>"><i class="lni lni-grid-alt"></i></a><a href="<?php echo e(route('list',$cat->slug)); ?>"><i class="lni lni-radio-button"></i></a></div>
            </div>
            <div class="row g-3">



                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-md-6">
                    <div class="card weekly-product-card">
                        <div class="card-body d-flex align-items-center">
                            <div class="product-thumbnail-side">
                                <span class="badge badge-danger">-<?php echo e($item->takhfif); ?>٪</span>
                                <a class="wishlist-btn" href="<?php echo e(route('single',$item->slug)); ?>">
                                    <i class="lni lni-heart"></i>
                                </a>
                                <a class="product-thumbnail d-block" href="<?php echo e(route('single',$item->slug)); ?>">
                                    <img class="mb-2" src="<?php echo e(url('images/product/thumb/'.$item->image)); ?>" alt="<?php echo e($item->slug); ?>">
                                </a>
                            </div>
                            <div class="product-description">
                                <a class="product-title d-block" href="<?php echo e(route('single',$item->slug)); ?>"><?php echo e($item->name); ?></a>
                                <p class="sale-price">
                                    <i class="lni lni-dollar"></i>
                                    <?php echo e((($item->price)-((($item->price)*($item->takhfif))/100))); ?>

                                    تومان
                                    <span>
                                        <?php echo e($item->price); ?>

                                        تومان

                                    </span>

                                </p>
                                <div class="product-rating">
                                    <i class="lni lni-star-filled"></i>
                                    <?php echo e($item->ratee); ?>

                                </div>
                                <a onclick="addtoo(<?php echo e($item->id); ?>)" class="btn btn-success btn-sm add2cart-notify">
                                    <i class="mr-1 lni lni-cart"></i>

                                    خرید

                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



            </div>
        </div>
    </div>





<?php $__env->stopSection(); ?>




<?php echo $__env->make('front.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\rebo\resources\views/front/list/main.blade.php ENDPATH**/ ?>