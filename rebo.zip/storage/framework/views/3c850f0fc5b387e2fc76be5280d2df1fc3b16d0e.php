<div class="top-products-area clearfix py-3">
    <div class="container">
        <div class="section-heading d-flex align-items-center justify-content-between">
            <h6 class="ml-1">پرفروش ها</h6><a class="btn btn-danger btn-sm" href="">مشاهده همه</a>
        </div>


<div class="row g-3">
    <!-- Single Top Product Card-->
    <div class="col-6 col-md-4 col-lg-3">
        <div class="card top-product-card">
            <div class="card-body"><span class="badge badge-success">فروش</span><a class="wishlist-btn" href="#"><i class="lni lni-heart"></i></a><a class="product-thumbnail d-block" href="single-product.html"><img class="mb-2" src="front/img/product/11.png" alt=""></a><a class="product-title d-block" href="single-product.html">نام محصول</a>
                <p class="sale-price">36 تومان <span class="real-price"> 65 تومان</span></p>
                <div class="product-rating"><i class="lni lni-star-filled"></i><i class="lni lni-star-filled"></i><i class="lni lni-star-filled"></i><i class="lni lni-star-filled"></i><i class="lni lni-star-filled"></i></div><a class="btn btn-success btn-sm add2cart-notify" href="#"><i class="lni lni-plus"></i></a>
            </div>
        </div>
    </div>



</div>
</div>
</div>
<?php /**PATH D:\xamp\htdocs\rebo\resources\views/front/index/mostsale.blade.php ENDPATH**/ ?>