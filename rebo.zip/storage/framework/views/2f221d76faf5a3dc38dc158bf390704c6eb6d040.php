<div class="product-ratings">
    <div class="container d-flex align-items-center justify-content-between">
        <div class="ratings">

            <?php for($i=0;$i<$averagecoment-1;$i++): ?>
            <i class="lni lni-star-filled"></i>

            <?php endfor; ?>
            <span class="pl-1">

                <?php echo e($averagecoment); ?>


                ستاره</span></div>
        <div class="total-result-of-ratings"><span><?php echo e($averagecoment); ?></span><span>


            </span></div>
    </div>
</div>
<?php /**PATH D:\xamp\htdocs\rebo\resources\views/front/single/rating.blade.php ENDPATH**/ ?>