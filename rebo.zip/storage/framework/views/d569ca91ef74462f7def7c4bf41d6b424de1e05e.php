
<div class="flash-sale-wrapper mt-4">
    <div class="container">
        <div class="section-heading d-flex align-items-center justify-content-between">
            <h6 class="ml-1">ویژه</h6><a class="btn btn-primary btn-sm" href="">مشاهده همه</a>
        </div>
        <!-- Flash Sale Slide-->

<div class="flash-sale-slide owl-carousel">



<?php $__currentLoopData = $products_vije; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vije): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="card flash-sale-card">
        <div class="card-body"><a href="<?php echo e(route('single',$vije->slug)); ?>">

                <img src="<?php echo e(url('images/product/thumb/'.$vije->image)); ?>" alt="<?php echo e($vije->slug); ?>" >



                <span class="product-title"><?php echo e($vije->name); ?></span>
                <p class="sale-price"><?php echo e((($vije->price)-((($vije->price)*($vije->takhfif))/100))); ?> تومان <span class="real-price" style=" color: #d31b2d;"> <?php echo e($vije->price); ?>  تومان </span></p>
                <!-- Progress Bar-->
                <div class="progress">
                    <div class="progress-bar" role="progressbar" style="width: 100%;" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                </div></a></div>
    </div>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</div>
</div>
</div>

<br>
<?php /**PATH D:\xamp\htdocs\rebo\resources\views/front/index/vije.blade.php ENDPATH**/ ?>