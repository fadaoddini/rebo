<!-- Logo Wrapper-->
<div class="logo-wrapper"><a href="<?php echo e(route('index')); ?>"><img width="50" src="<?php echo e(url('/images/setting/logo.png')); ?>" alt="Rebo"></a></div>
<!-- Search Form-->
<div class="top-search-form">
    <form action="#" method="">
        <input class="form-control" type="search" placeholder="کلمه کلیدی خود را وارد کنید">
        <button type="submit"><i class="fa fa-search"></i></button>
    </form>
</div>
<!-- Navbar Toggler-->
<div class="suha-navbar-toggler d-flex flex-wrap" id="suhaNavbarToggler"><span></span><span></span><span></span></div>
<?php /**PATH D:\xamp\htdocs\rebo\resources\views/front/topmenu.blade.php ENDPATH**/ ?>