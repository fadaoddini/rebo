<style>
    .cta-area .cta-text::after{
        background: linear-gradient(to right, <?php echo e($adver1->bgcolor); ?>, <?php echo e($adver1->bgcolor2); ?>);
    }
</style>
<div class="cta-area   ">
    <div class="container">


<div class="cta-text p-4 p-lg-5" style="background-image: url('images/adver/thumb/<?php echo e($adver1->image); ?>')">
    <h4><?php echo e($adver1->name); ?></h4>
    <p>
        <?php echo e($adver1->lid); ?>

    </p>

    <a class="btn btn-danger" href="  <?php echo e($adver1->link); ?>">
        <?php echo e($adver1->title_link); ?>


    </a>
</div>

</div>
</div>
<?php /**PATH D:\xamp\htdocs\rebo\resources\views/front/index/ads1.blade.php ENDPATH**/ ?>