
<div class="rating-and-review-wrapper bg-white py-3 mb-3">
    <div class="container">
        <h6>رتبه بندی ها ونظر ها</h6>
        <div class="rating-review-content">
            <ul class="pl-0">


                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="single-user-review d-flex">
                    <div class="user-thumbnail"><img src="img/bg-img/7.jpg" alt=""></div>
                    <div class="rating-comment">
                        <div class="rating">

                            <?php for($i=0;$i<$row->rating;$i++): ?>
                                <i class="lni lni-star-filled"></i>
                                <?php endfor; ?>




                        </div>
                        <p class="comment mb-0"><?php echo e($row->body); ?></p><span class="name-date"><?php echo e($row->name); ?></span>
                    </div>
                </li>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </ul>
        </div>
    </div>
</div>
<?php /**PATH D:\xamp\htdocs\rebo\resources\views/front/single/ratingcomment.blade.php ENDPATH**/ ?>