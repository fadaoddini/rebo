<div class="p-specification bg-white mb-3 py-3">
    <div class="container">
        <h6>مواد تشکیل دهنده</h6>
        <p>
            <?php echo e($product_single->lid); ?>

        </p>
        
    </div>
</div>
<?php /**PATH D:\xamp\htdocs\rebo\resources\views/front/single/fani.blade.php ENDPATH**/ ?>