<?php $__env->startSection('content'); ?>



    <div class="container">

    <?php echo $__env->make('front.etc.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Profile Wrapper-->
        <div class="profile-wrapper-area py-3">
            <!-- User Information-->
            <div class="card user-info-card">
                <div class="card-body p-4 d-flex align-items-center">
                    <div class="user-profile mr-3">

                        <?php if(($user->image) != ""): ?>

                            <img src="<?php echo e(url('/images/profile/thumb/'.$user->image)); ?>" alt="<?php echo e($user->family); ?>">
                        <?php else: ?>

                            <img src="<?php echo e(url('/images/profile/profile.png')); ?>" alt="<?php echo e($user->family); ?>">
                        <?php endif; ?>


                        <div class="change-user-thumb">
                            <form  method="post" action="<?php echo e(route('updatepicprofile',$user->id)); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <input onchange="this.form.submit();" name="image" class="form-control-file" type="file">
                                <button ><i class="lni lni-pencil"></i></button>


                            </form>
                        </div>
                    </div>
                    <div class="user-info">
                        <p class="mb-0 text-white"><?php echo e($user->name); ?></p>
                        <h5 class="mb-0"><?php echo e($user->family); ?></h5>
                    </div>
                </div>
            </div>
            <!-- User Meta Data-->
            <div class="card user-data-card">
                <div class="card-body">
                    <form action="<?php echo e(route('updateprofile',$user->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <div class="title mb-2"><i class="lni lni-user"></i><span>نام </span></div>
                            <input name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " type="text"
                                   value="<?php echo e($user->name); ?> ">

                        </div>
                        <div class="mb-3">
                            <div class="title mb-2"><i class="lni lni-user "></i><span>نام خانوادگی</span></div>
                            <input name="family" class="form-control <?php $__errorArgs = ['family'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                                   value="<?php echo e($user->family); ?>">
                        </div>
                        <div class="mb-3">
                            <div class="title mb-2"><i class="lni lni-phone "></i><span>موبایل</span></div>
                            <input name="mobile" class="form-control <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                                   value="<?php echo e($user->mobile); ?>">
                        </div>
                        <div class="mb-3">
                            <div class="title mb-2"><i class="lni lni-flag "></i><span> شهر</span></div>
                            <input name="city" class="form-control <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                                   value="<?php echo e($user->city); ?>">
                        </div>


                        <div class="mb-3">
                            <div class="title mb-2"><i class="lni lni-lock "></i><span> رمزعبور</span></div>
                            <input name="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="password"
                                   value="">
                        </div>


                        <div class="mb-3 ">
                            <div class="title mb-2"><i class="lni lni-lock "></i><span> تکرار رمزعبور</span></div>
                            <input type="password" name="password_confirmation" class="form-control <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                                   value="">
                        </div>






                        <div class="mb-3">
                            <div class="title mb-2"><i class="lni lni-list "></i><span>توضیحات</span></div>


                            <textarea name="description"
                                      class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e($user->description); ?></textarea>

                        </div>
                        <button class="btn btn-success w-100" type="submit">ذخیره همه تغییرات</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\rebo\resources\views/front/user/editprofile.blade.php ENDPATH**/ ?>