<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('back.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="product-slides owl-carousel">

            <div class="single-product-slide" style="background-image: url('images/product/thumb/<?php echo e($product_single->image); ?>')"></div>
          
        </div>
        <div class="product-description pb-3">

            <div class="product-title-meta-data bg-white mb-3 py-3">
                <div class="container d-flex justify-content-between">
                    <div class="p-title-price">
                        <h6 class="mb-1"><?php echo e($product_single->name); ?>   </h6>
                        <p class="sale-price mb-0">
                            <?php echo e((($product_single->price)-((($product_single->price)*($product_single->takhfif))/100))); ?>

                            تومان
                            <span><?php echo e($product_single->price); ?>

                                تومان
                            </span></p>
                    </div>
                    <div class="p-wishlist-share"><a href="wishlist-grid.html"><i class="lni lni-heart"></i></a></div>
                </div>
                <?php echo $__env->make('front.single.rating', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
           
            <?php echo $__env->make('front.single.addcart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('front.single.fani', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('front.single.ratingcomment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('front.single.ratingsubmit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\rebo\resources\views/front/single/main.blade.php ENDPATH**/ ?>