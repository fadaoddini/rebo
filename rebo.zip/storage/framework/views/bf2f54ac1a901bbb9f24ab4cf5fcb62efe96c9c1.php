<!DOCTYPE html>

<html direction="rtl" dir="rtl" style="direction: rtl">

<head>
    <base href="">
    <meta charset="utf-8"/>
    <title><?php echo $__env->yieldContent('webtitleadmin'); ?></title>
    <meta name="description" content="Updates and statistics"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
    <link href="<?php echo e(url('/admin/css/googlefont.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(url('/admin/css/app.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(url('/admin/css/style.bundle.rtl.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(url('/admin/css/global/plugins.bundle.rtl.css')); ?>" rel="stylesheet" type="text/css"/>

    <link href="<?php echo e(url('/admin/css/plugins/custom/datatables/datatables.bundle.rtl.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(url('/admin/css/plugins/global/plugins.bundle.rtl.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(url('/admin/css/plugins/custom/prismjs/prismjs.bundle.rtl.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(url('/admin/css/global/plugins.bundle.rtl.css')); ?>" rel="stylesheet" type="text/css"/>

    <link rel="shortcut icon" href="assets/media/logos/favicon.ico"/>
</head>
<?php /**PATH D:\xamp\htdocs\rebo\resources\views/back/headeradmin.blade.php ENDPATH**/ ?>