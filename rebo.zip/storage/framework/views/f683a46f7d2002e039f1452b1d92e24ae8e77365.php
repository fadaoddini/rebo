


<div class="hero-slides owl-carousel">


    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="single-hero-slide" style="background-image: url('images/slider/thumb/<?php echo e($slide->image); ?>')">
        <div class="slide-content h-100 d-flex align-items-center">
            <div class="container">
                <h4 class="text-white mb-0" data-animation="fadeInUp" data-delay="100ms" data-wow-duration="1000ms"><?php echo e($slide->name); ?></h4>
                <p class="text-white" data-animation="fadeInUp" data-delay="400ms" data-wow-duration="1000ms"><?php echo e($slide->lid); ?></p><a class="btn btn-primary btn-sm" href="<?php echo e($slide->link); ?>" data-animation="fadeInUp" data-delay="800ms" data-wow-duration="1000ms"><?php echo e($slide->title_link); ?></a>
            </div>
        </div>
    </div>


    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



</div>
<?php /**PATH D:\xamp\htdocs\rebo\resources\views/front/index/topslider.blade.php ENDPATH**/ ?>