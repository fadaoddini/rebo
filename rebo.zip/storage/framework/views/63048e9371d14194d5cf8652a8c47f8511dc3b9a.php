<div class="product-catagories-wrapper py-3">
    <div class="container">
        <div class="section-heading">
            <h6 class="ml-1">دسته بندی محصولات</h6>
        </div>
        <div class="product-catagory-wrap">
            <div class="row g-3">


                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <!-- Single Catagory Card-->
                <div class="col-4">
                    <div class="card catagory-card">
                        <div class="card-body"><a href="<?php echo e(route('grid',$cat->slug)); ?>">

                                <img src="<?php echo e(url('images/category/thumb/'.$cat->image)); ?>" alt="<?php echo e($cat->slug); ?>" >


                                <span><?php echo e($cat->name); ?></span></a></div>
                    </div>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\xamp\htdocs\rebo\resources\views/front/index/category.blade.php ENDPATH**/ ?>