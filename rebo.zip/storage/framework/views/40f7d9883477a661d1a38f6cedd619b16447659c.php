
<div class="suha-sidenav-wrapper" id="sidenavWrapper">

<?php if(auth()->guard()->check()): ?>
    <!-- Sidenav Profile-->
        <div class="sidenav-profile">
            <div class="user-profile">

                <?php if((auth()->user()->image) != ""): ?>

                    <img src="<?php echo e(url('/images/profile/thumb/'.auth()->user()->image)); ?>" alt="<?php echo e(auth()->user()->family); ?>">
                <?php else: ?>

                    <img src="<?php echo e(url('/images/profile/profile.png')); ?>" alt="<?php echo e(auth()->user()->family); ?>">
                <?php endif; ?>

            </div>
            <div class="user-info">
                <h6 class="user-name mb-0"><?php echo e(auth()->user()->name); ?></h6>
                <p class="available-balance">امتیاز شما <span><span class="counter"><?php echo e(auth()->user()->emtiaz); ?></span></span><span> می باشد</span></p>
            </div>
        </div>


        <?php if(Auth::user()->role=='1'): ?>
            <ul class="sidenav-nav pl-0">

                <li><a href="<?php echo e(route('rebo')); ?>"><i class="lni lni-cog"></i>مدیریت</a></li>

            </ul>

    <?php endif; ?>
    <!-- Sidenav Nav-->
        <ul class="sidenav-nav pl-0">
            <li><a href="<?php echo e(route('profile')); ?>"><i class="lni lni-user"></i>پروفایل من</a></li>
            <li><a href="notifications.html"><i class="lni lni-alarm lni-tada-effect"></i>اطلاعیه ها <span class="ml-3 badge badge-warning">3</span></a></li>



            <li><a href="settings.html"><i class="lni lni-cog"></i>تنظیمات</a></li>
            <li>
                <form action="<?php echo e(route('logout')); ?>" method="post">

                    <?php echo csrf_field(); ?>
                    <button class="btn btn-danger" type="submit"><i class="lni lni-power-switch"></i>خروج از سیستم</button>

                </form>
            </li>
        </ul>




<?php else: ?>
    <!-- Sidenav Profile-->
        <div class="sidenav-profile">
            <div class="user-profile"><img src="<?php echo e(url('front/img/core-img/logo-small.png')); ?>" alt=""></div>
            <div class="user-info">
                <h6 class="user-name mb-0">ربو تولدی دوباره</h6>
            </div>
        </div>
        <!-- Sidenav Nav-->
        <ul class="sidenav-nav pl-0">
            <li><a href="login"><i class="lni lni-user"></i>ورود</a></li>

        </ul>


<?php endif; ?>

<!-- Go Back Button-->
    <div class="go-home-btn" id="goHomeBtn"><i class="lni lni-arrow-right"></i></div>
</div>
<?php /**PATH D:\xamp\htdocs\rebo\resources\views/front/sidebare.blade.php ENDPATH**/ ?>