
<div class="container">
    <div class="card discount-coupon-card border-0">
        <div class="card-body">


<div class="coupon-text-wrap d-flex align-items-center p-3">
    <h5 class="text-white pr-3 mb-0">%20 <br>تخفیف دریافت کنید</h5>
    <p class="text-white pl-3 mb-0">برای دریافت تخفیف ، کد <strong class="px-1">GET20</strong> را در صفحه پرداخت وارد کنید .</p>
</div>

</div>
</div>
</div>
<?php /**PATH D:\xamp\htdocs\rebo\resources\views/front/index/ads2.blade.php ENDPATH**/ ?>