<div class="cart-form-wrapper bg-white mb-3 py-3">
    <div class="container">
        <form class="cart-form" action="#" method="">
            <div class="order-plus-minus d-flex align-items-center">
                <div class="quantity-button-handler">-</div>
                <input class="form-control cart-quantity-input" type="text" step="1" name="quantity" value="3">
                <div class="quantity-button-handler">+</div>
            </div>
            <button class="btn btn-danger ml-3" type="submit">افزودن به سبد خرید</button>
        </form>
    </div>
</div>
<?php /**PATH D:\xamp\htdocs\rebo\resources\views/front/single/addcart.blade.php ENDPATH**/ ?>