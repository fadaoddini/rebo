<div class="toast pwa-install-alert shadow" id="pwaInstallToast" role="alert" aria-live="assertive" aria-atomic="true" data-delay="8000" data-autohide="true">
    <div class="toast-body">
        <button class="ml-3 close" type="button" data-dismiss="toast" aria-label="نزدیک"><span aria-hidden="true">×</span></button>
        <div class="content d-flex align-items-center mb-2"><img src="img/icons/icon-72x72.png" alt="">
            <h6 class="mb-0 text-white">افزودن به صفحه اصلی</h6>
        </div><span class="mb-0 d-block text-white">ربو را در صفحه اصلی تلفن همراه خود اضافه کنید. بر روی دکمه <strong class="mx-1">"افزودن به صفحه اصلی"</strong> کلیک کنید و مانند یک برنامه معمولی از آن لذت ببرید.</span>
    </div>
</div>
