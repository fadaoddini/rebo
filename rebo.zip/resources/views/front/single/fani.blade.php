<div class="p-specification bg-white mb-3 py-3">
    <div class="container">
        <h6>مواد تشکیل دهنده</h6>
        <p>
            {{$product_single->lid}}
        </p>
        {{--<ul class="mb-3 pl-3">
            <li><i class="lni lni-checkmark-circle"> </i> ٪100 نظرات خوب </li>
            <li><i class="lni lni-checkmark-circle"> </i> 7 روز گارانتی برگشت </li>
            <li> <i class="lni lni-checkmark-circle"> </i> تحویل فوری </li>
            <li> <i class="lni lni-checkmark-circle"> </i> ٪100 محصول جدید </li>
        </ul>
        <p class="mb-0">لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است</p>--}}
    </div>
</div>
