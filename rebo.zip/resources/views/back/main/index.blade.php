@extends('back.index')
@section('webtitleadmin')
پنل مدیریت سایت
@endsection
@section('content')
    <section>
        داشبورد
    </section>

@endsection