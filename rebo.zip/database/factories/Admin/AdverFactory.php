<?php

namespace Database\Factories\admin;

use App\Models\admin\Adver;
use Illuminate\Database\Eloquent\Factories\Factory;

class AdverFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Adver::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
