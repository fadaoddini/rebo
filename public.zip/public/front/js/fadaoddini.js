function addtoo(id) {



    var name = $("#name" + id + "").val();



    var text_back = name + ' به سبد خرید اضافه گردید ';
    var type = "GET";
    alert(text_back);
    $.ajax({

        url: "{{ route('addtoo') }}",

        type: type,

        data: {

            id: id,
            name: name

        },

        success: function (response) {

            if (response) {

alert('1');
                console.log(response);
                $('#msg').text(text_back);
            } else {
                $('#msg').text('خطا در کنترلر کلیک اجاکسی');
                alert('2');
            }

        }

    });


}
